import { mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import { Script } from 'node:vm';
import { fileURLToPath } from 'node:url';
const root = new URL('../', import.meta.url);
const output = new URL('dist/', root);
const sourceFiles = [
  'src/seatAssignmentRules.js',
  'src/validation.js',
  'src/seatAssignment.js',
  'src/state.js',
  'src/countdown.js',
  'src/components.js',
  'src/app.js',
];
const read = async (path) => readFile(new URL(path, root), 'utf8');
const sources = await Promise.all(sourceFiles.map(read));
const script = sources.map((source, index) => {
  const withoutImports = source.replace(/^import\s+[^\n]+;\s*$/gm, '');
  if (/^import\s/m.test(withoutImports)) throw new Error(`처리하지 못한 import가 있습니다: ${sourceFiles[index]}`);
  return withoutImports.replace(/^export\s+/gm, '');
}).join('\n\n');
new Script(script);
const favicon = (await readFile(new URL('favicon.svg', root))).toString('base64');
const html = (await read('index.template.html'))
  .replace('{{FAVICON}}', favicon)
  .replace('{{STYLES}}', await read('src/styles.css'))
  .replace('{{SCRIPT}}', script);
if (/\{\{(?:FAVICON|STYLES|SCRIPT)\}\}/.test(html)) throw new Error('HTML 생성값이 누락되었습니다.');
// 삭제 대상은 이 스크립트가 소속된 프로젝트의 dist 디렉터리로 고정합니다.
await rm(output, { recursive: true, force: true });
await mkdir(output, { recursive: true });
await writeFile(new URL('index.html', root), html);
await writeFile(new URL('index.html', output), html);
console.log(`파일로 직접 열 수 있는 HTML 생성 완료: ${fileURLToPath(new URL('index.html', root))}`);
console.log(`Render 배포 파일 생성 완료: ${fileURLToPath(output)}`);
