import { getDistantStudents, getRequiredAssignments, isDistantFromAnchor } from './seatAssignmentRules.js';
import { validateSettings } from './validation.js';

export function shuffleArray(array, random = Math.random) {
  const result = [...array];
  for (let i = result.length - 1; i > 0; i--) {
    const j = Math.floor(random() * (i + 1));
    [result[i], result[j]] = [result[j], result[i]];
  }
  return result;
}

export function verifyAssignments(studentCount, seats) {
  const assigned = seats.filter((seat) => seat.student !== null);
  const numbers = assigned.map((seat) => seat.student);
  if (assigned.length !== studentCount || new Set(numbers).size !== studentCount ||
      assigned.some((seat) => !seat.active) ||
      numbers.some((n) => !Number.isInteger(n) || n < 1 || n > studentCount)) return false;
  return getRequiredAssignments(studentCount).every(({ student, row, col }) =>
    seats.some((seat) => seat.row === row && seat.col === col && seat.student === student)) &&
    getDistantStudents(studentCount).every((student) =>
      assigned.some((seat) => seat.student === student && isDistantFromAnchor(seat)));
}

export function validateAssignmentSettings(studentCount, seats) {
  const error = validateSettings(studentCount, seats);
  if (error) throw new Error(error);
  for (const { row, col } of getRequiredAssignments(studentCount)) {
    if (!seats.some((seat) => seat.row === row && seat.col === col && seat.active)) {
      throw new Error('좌석 설정을 확인한 후 다시 시도해주세요.');
    }
  }
  const reserved = getRequiredAssignments(studentCount);
  const distantSeats = seats.filter((seat) => seat.active && isDistantFromAnchor(seat) &&
    !reserved.some((rule) => seat.row === rule.row && seat.col === rule.col));
  if (distantSeats.length < getDistantStudents(studentCount).length) {
    throw new Error('현재 좌석 설정으로는 자리 배정을 완료할 수 없습니다. 좌석을 더 활성화해주세요.');
  }
}

export function createSeatAssignments(studentCount, seats, random = Math.random) {
  validateAssignmentSettings(studentCount, seats);
  const result = seats.map((seat) => ({ ...seat, student: null }));
  const required = getRequiredAssignments(studentCount);
  for (const { student, row, col } of required) {
    const target = result.find((seat) => seat.row === row && seat.col === col);
    if (!target?.active) throw new Error('좌석 설정을 확인한 후 다시 시도해주세요.');
    target.student = student;
  }
  const distantStudents = shuffleArray(getDistantStudents(studentCount), random);
  const distantSeats = shuffleArray(result.filter((seat) => seat.active && seat.student === null && isDistantFromAnchor(seat)), random);
  distantStudents.forEach((student, index) => { distantSeats[index].student = student; });
  const students = Array.from({ length: studentCount }, (_, i) => i + 1)
    .filter((student) => !required.some((rule) => rule.student === student) && !distantStudents.includes(student));
  const available = shuffleArray(result.filter((seat) => seat.active && seat.student === null), random);
  shuffleArray(students, random).forEach((student, index) => { available[index].student = student; });
  if (!verifyAssignments(studentCount, result)) throw new Error('자리 배정을 완료하지 못했습니다. 다시 시도해주세요.');
  return result;
}
