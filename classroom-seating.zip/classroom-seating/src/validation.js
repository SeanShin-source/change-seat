export function isValidStudentCount(value) {
  return Number.isInteger(value) && value >= 1 && value <= 30;
}

export function parseStudentCount(value) {
  if (!/^\d+$/.test(String(value))) return null;
  const count = Number(value);
  return isValidStudentCount(count) ? count : null;
}

export function validateSettings(studentCount, seats) {
  if (!isValidStudentCount(studentCount)) return '학생 수는 1명부터 30명까지 입력해주세요.';
  if (seats.filter((seat) => seat.active).length < studentCount) {
    return '학생 수보다 사용 가능한 좌석이 부족합니다.';
  }
  return '';
}
