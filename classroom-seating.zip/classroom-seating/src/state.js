import { isProtectedSeat } from './seatAssignmentRules.js';
import { isValidStudentCount } from './validation.js';
import { createSeatAssignments, validateAssignmentSettings } from './seatAssignment.js';

export const ROWS = 6;
export const COLUMNS = 6;
export function createSeats() {
  return Array.from({ length: ROWS * COLUMNS }, (_, index) => ({
    id: `${Math.floor(index / COLUMNS)}-${index % COLUMNS}`,
    row: Math.floor(index / COLUMNS), col: index % COLUMNS, active: true, student: null,
  }));
}
export function createInitialState() {
  return { phase: 'welcome', studentCount: 26, seats: createSeats(), countdown: null, error: '' };
}
export function reduceState(state, action) {
  if (action.type === 'START' && state.phase === 'welcome') return { ...state, phase: 'setup' };
  if (state.phase === 'countdown') {
    if (action.type === 'TICK') return { ...state, countdown: action.value };
    if (action.type === 'COMPLETE') {
      try {
        return { ...state, phase: 'complete', countdown: null,
          seats: createSeatAssignments(state.studentCount, state.seats) };
      } catch (error) {
        return { ...state, phase: 'setup', countdown: null, error: error.message };
      }
    }
    return state;
  }
  if (state.phase !== 'setup') return state;
  switch (action.type) {
    case 'SET_COUNT':
      return isValidStudentCount(action.value) ? { ...state, studentCount: action.value, error: '' } : state;
    case 'TOGGLE_SEAT':
      return { ...state, error: '', seats: state.seats.map((seat) =>
        seat.id === action.id && !isProtectedSeat(seat) ? { ...seat, active: !seat.active } : seat) };
    case 'ACTIVATE_ALL':
      return { ...state, error: '', seats: state.seats.map((seat) => ({ ...seat, active: true })) };
    case 'RESET': return { ...createInitialState(), phase: 'setup' };
    case 'ERROR': return { ...state, error: action.message };
    case 'SHUFFLE':
      try {
        // 카운트다운 전에 모든 조건을 검사하되, 실제 결과는 공개 순간 생성합니다.
        validateAssignmentSettings(state.studentCount, state.seats);
        return { ...state, phase: 'countdown', countdown: 3, error: '' };
      } catch (error) { return { ...state, error: error.message }; }
    default: return state;
  }
}
