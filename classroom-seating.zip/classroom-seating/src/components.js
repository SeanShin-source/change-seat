export function icon(name, className = '') {
  const paths = {
    grid: '<rect x="3" y="3" width="7" height="7" rx="2"/><rect x="14" y="3" width="7" height="7" rx="2"/><rect x="3" y="14" width="7" height="7" rx="2"/><rect x="14" y="14" width="7" height="7" rx="2"/>',
    shuffle: '<path d="m17 3 4 4-4 4M3 7h3c5 0 7 10 12 10h3m-4-4 4 4-4 4M3 17h3c2 0 3.5-2 5-4m3-4c1-1.3 2.3-2 4-2h3"/>',
    reset: '<path d="M3 10a9 9 0 1 1 2 8M3 4v6h6"/>',
    arrow: '<path d="M5 12h14m-5-5 5 5-5 5"/>',
    info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v6m0-10v.1"/>',
    check: '<path d="m5 12 4 4L19 6"/>',
    desk: '<path d="M3 8h18v6H3zm3 6v6m12-6v6M6 4h12"/>',
    help: '<circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 1 1 4 2c-1 .7-1.5 1.2-1.5 2m0 3v.1"/>',
  };
  return `<svg class="icon ${className}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name] || paths.grid}</svg>`;
}

export const notices = [
  '학생 번호는 1번부터 최대 30번까지 설정할 수 있습니다.',
  '사용하지 않는 자리는 좌석을 클릭하여 비활성화할 수 있습니다.',
  '비활성화된 자리에는 학생 번호가 배정되지 않습니다.',
  '자리 배정을 시작하기 전에 학생 수와 사용 가능한 좌석 수를 확인해주세요.',
];

export function welcomeScreen() {
  return `<main class="welcome"><div class="welcome-card">
    <div class="brand-mark large">${icon('grid')}</div><p class="eyebrow">우리 교실의 새로운 시작</p>
    <h1>자리바꾸기 프로그램 실행하기</h1><p class="welcome-subtitle">자리바꾸기를 시작하기 전 아래 유의사항을 확인해주세요.</p>
    <ol class="notice-list">${notices.map((notice) => `<li>${notice}</li>`).join('')}</ol>
    <div class="notice-highlight">${icon('info')}<p><strong>자리를 한 번 바꾼 뒤엔 자리를 다시 바꿀 수 없어요!</strong><br><span>설정을 모두 확인한 후 자리 배정을 시작해주세요.</span></p></div>
    <button type="button" class="button primary start-button" id="start">시작하기 ${icon('arrow')}</button>
    <p class="welcome-footer">즐거운 교실, 새로운 자리로</p>
  </div></main>`;
}

export function mainScreen() {
  return `<div class="app-shell">
    <header class="app-header"><div class="brand"><div class="brand-mark">${icon('grid')}</div><div><h1 id="main-title" tabindex="-1">자리바꾸기</h1><p>즐거운 교실, 새로운 자리로</p></div></div>
      <button class="button help-button" id="help" type="button">${icon('help')}<span>사용 안내</span></button></header>
    <main class="workspace">
      <aside class="settings card" aria-label="자리 배정 설정">
        <section><h2><span class="step-number">1</span>번호 범위 설정</h2>
          <label for="student-count">학생 수 <span class="muted">(1 ~ 30명)</span></label>
          <div class="number-range"><span class="range-start">1</span><span class="range-separator">~</span><input id="student-count" type="number" min="1" max="30" step="1" value="26" inputmode="numeric" required aria-describedby="count-description input-error" /><span class="student-total">총 <strong id="student-total">26</strong>명</span></div>
          <p id="input-error" class="input-error" role="alert" hidden></p>
          <p id="count-description" class="hint">${icon('info')}<span>1부터 지정한 수까지의 번호가<br>무작위로 배정됩니다.</span></p>
        </section>
        <section class="seat-settings"><h2><span class="step-number">2</span>좌석 선택 <span class="optional">선택 사항</span></h2>
          <p class="section-description">사용하지 않는 좌석을 클릭해주세요.<br>한 번 더 누르면 다시 사용할 수 있어요.</p>
          <button id="activate-all" type="button" class="button secondary">${icon('grid')}모두 활성화</button>
        </section>
        <section class="assignment-settings"><h2><span class="step-number">3</span>자리 배정</h2>
          <div class="readiness"><span>배정할 학생 <strong id="summary-count">26명</strong></span><span>사용 가능 <strong id="available-count">36석</strong></span></div>
          <div id="settings-error" class="settings-error" role="alert" hidden></div>
          <button id="shuffle" type="button" class="button primary">${icon('shuffle')}<span>자리 섞기</span></button>
          <p id="completion-notice" class="completion-notice" hidden>${icon('info')}<span>자리를 한 번 바꾼 뒤엔 자리를 다시 바꿀 수 없어요!</span></p>
          <button id="reset" type="button" class="button reset-button">${icon('reset')}초기화</button>
        </section>
        <p class="settings-footnote">설정이 끝나면 자리 섞기를 눌러주세요.</p>
      </aside>
      <section class="classroom card" aria-labelledby="classroom-title">
        <div class="classroom-heading"><div><h2 id="classroom-title">우리 반 좌석표</h2><span class="room-dimensions">6열 × 6행 · 총 36석</span></div><span id="phase-badge" class="phase-badge">좌석 설정 중</span></div>
        <div class="room"><div class="front-label"><span></span>교실 앞쪽<span></span></div><div class="teacher-desk">${icon('desk')}교탁</div>
          <div class="column-labels" aria-hidden="true">${Array.from({length: 6}, (_, i) => `<span>${i + 1}열</span>`).join('')}</div>
          <div id="seat-grid" class="seat-grid" aria-label="6행 6열 교실 좌석"></div><div class="back-label">교실 뒤쪽</div>
        </div>
        <footer class="seat-footer"><div class="legend"><span><i class="legend-box"></i>활성 좌석</span><span><i class="legend-box inactive"></i>비활성 좌석</span></div><p class="seat-counter"><span>활성 <strong id="active-count">36</strong>개</span><span class="counter-divider">|</span><span>비활성 <strong id="inactive-count">0</strong>개</span></p></footer>
      </section>
    </main>
    <footer class="page-footer"><span>우리 교실, 함께 만드는 새로운 하루</span><span id="status-message" role="status" aria-live="polite">학생 수와 사용할 좌석을 확인해주세요.</span></footer>
  </div>
  <dialog id="help-dialog" class="help-dialog" aria-labelledby="help-title"><h2 id="help-title">자리바꾸기 사용 안내</h2><ol class="notice-list">${notices.map((notice) => `<li>${notice}</li>`).join('')}</ol><p class="hint">자리 배정이 끝나면 설정을 변경할 수 없습니다.<br>새로 시작하려면 페이지를 새로고침해주세요.</p><button id="close-help" type="button" class="button primary">확인</button></dialog>
  <div id="countdown-overlay" class="countdown-overlay" role="dialog" aria-modal="true" aria-labelledby="countdown-title" tabindex="-1" hidden><div class="countdown-card"><p id="countdown-title">새로운 자리를 준비하고 있어요</p><div id="countdown-number" class="countdown-number" role="status" aria-live="assertive" aria-atomic="true">3</div><span>잠시 후 우리 반 자리가 공개됩니다.</span></div></div>`;
}
