// UI에는 규칙의 설명이나 식별자를 전달하지 않습니다.
const FIXED_SEATS = Object.freeze([
  Object.freeze({ student: 2, row: 5, col: 0 }),
  Object.freeze({ student: 18, row: 4, col: 0 }),
  Object.freeze({ student: 25, row: 4, col: 1 }),
]);

const DISTANT_STUDENTS = Object.freeze([20, 21, 26]);
const ANCHOR_SEAT = Object.freeze({ row: 5, col: 0 });

export function isProtectedSeat(seat) {
  return FIXED_SEATS.some(({ row, col }) => seat.row === row && seat.col === col);
}

export function getRequiredAssignments(studentCount) {
  return FIXED_SEATS.filter(({ student }) => student <= studentCount);
}

export function getDistantStudents(studentCount) {
  return DISTANT_STUDENTS.filter((student) => student <= studentCount);
}

export function isDistantFromAnchor(seat) {
  return Math.abs(seat.row - ANCHOR_SEAT.row) >= 2 ||
    Math.abs(seat.col - ANCHOR_SEAT.col) >= 2;
}
