export async function runCountdown(onTick, sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms))) {
  onTick(3);
  await sleep(1000);
  onTick(2);
  await sleep(1000);
  onTick(1);
  await sleep(1000);
}
