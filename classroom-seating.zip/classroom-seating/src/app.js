import { createInitialState, reduceState } from './state.js';
import { parseStudentCount } from './validation.js';
import { runCountdown } from './countdown.js';
import { welcomeScreen, mainScreen, icon } from './components.js';

const app = document.querySelector('#app');
let state = createInitialState();
const $ = (selector) => document.querySelector(selector);

function dispatch(action) {
  state = reduceState(state, action);
  renderState();
}

function renderState() {
  const locked = state.phase !== 'setup';
  const complete = state.phase === 'complete';
  const active = state.seats.filter((seat) => seat.active).length;
  for (const id of ['student-count', 'activate-all', 'shuffle', 'reset']) $(`#${id}`).disabled = locked;
  $('#student-total').textContent = state.studentCount;
  $('#summary-count').textContent = `${state.studentCount}명`;
  $('#available-count').textContent = `${active}석`;
  $('#available-count').classList.toggle('insufficient', active < state.studentCount);
  $('#active-count').textContent = active;
  $('#inactive-count').textContent = 36 - active;
  $('#settings-error').textContent = state.error;
  $('#settings-error').hidden = !state.error;
  $('#completion-notice').hidden = !complete;
  const shuffleButton = $('#shuffle');
  if (shuffleButton.dataset.phase !== state.phase) {
    shuffleButton.dataset.phase = state.phase;
    shuffleButton.innerHTML = `${icon(complete ? 'check' : 'shuffle')}<span>${complete ? '자리 배정 완료' : state.phase === 'countdown' ? '자리 배정 중' : '자리 섞기'}</span>`;
  }
  $('#phase-badge').textContent = complete ? '배정 완료' : state.phase === 'countdown' ? '배정 중' : '좌석 설정 중';
  $('#phase-badge').classList.toggle('complete', complete);
  $('.settings-footnote').textContent = complete ? '새로 시작하려면 페이지를 새로고침해주세요.' : '설정이 끝나면 자리 섞기를 눌러주세요.';
  $('#status-message').textContent = complete ? `${state.studentCount}명의 자리 배정이 완료되었습니다.` : active < state.studentCount ? `좌석이 ${state.studentCount - active}개 부족합니다.` : '학생 수와 사용할 좌석을 확인해주세요.';
  const buttons = $('#seat-grid').children;
  state.seats.forEach((seat, index) => {
    const button = buttons[index];
    button.disabled = locked;
    button.className = `seat${seat.active ? '' : ' inactive'}${seat.student !== null ? ' assigned' : ''}`;
    button.setAttribute('aria-pressed', String(seat.active));
    const description = !seat.active ? '비활성' : seat.student !== null ? `${seat.student}번` : complete ? '빈자리' : '활성';
    button.setAttribute('aria-label', `${seat.row + 1}행 ${seat.col + 1}열, ${description}`);
    const content = !seat.active ? '<span class="seat-dash">—</span><span class="seat-caption">비활성</span>'
      : seat.student !== null ? `<span class="seat-number">${seat.student}</span>`
      : complete ? '<span class="seat-caption">빈자리</span>' : '<span class="empty-seat-mark" aria-hidden="true"></span>';
    if (button.innerHTML !== content) button.innerHTML = content;
  });
  const counting = state.phase === 'countdown';
  $('#countdown-overlay').hidden = !counting;
  $('.app-shell').inert = counting;
  if (counting) $('#countdown-number').textContent = state.countdown;
}

function validateInput() {
  const input = $('#student-count');
  const count = parseStudentCount(input.value);
  const invalid = count === null;
  input.setAttribute('aria-invalid', String(invalid));
  $('#input-error').hidden = !invalid;
  $('#input-error').textContent = invalid ? '1부터 30까지의 정수를 입력해주세요.' : '';
  if (!invalid) dispatch({ type: 'SET_COUNT', value: count });
  return !invalid;
}

function start() {
  state = reduceState(state, { type: 'START' });
  app.innerHTML = mainScreen();
  for (const seat of state.seats) {
    const button = document.createElement('button');
    button.type = 'button';
    button.dataset.seatId = seat.id;
    button.addEventListener('click', () => dispatch({ type: 'TOGGLE_SEAT', id: seat.id }));
    $('#seat-grid').append(button);
  }
  const input = $('#student-count');
  input.addEventListener('beforeinput', (event) => {
    if (event.data && /[^0-9]/.test(event.data)) event.preventDefault();
  });
  input.addEventListener('input', () => {
    // 빈 입력은 편집 중 허용하지만, 추첨 시에는 반드시 정수 검증을 통과해야 합니다.
    if (/^\d+$/.test(input.value)) {
      const numeric = Number(input.value);
      if (numeric > 30) input.value = '30';
      if (numeric < 1) input.value = '1';
    }
    validateInput();
  });
  input.addEventListener('change', () => { if (validateInput()) input.value = String(state.studentCount); });
  $('#activate-all').addEventListener('click', () => dispatch({ type: 'ACTIVATE_ALL' }));
  $('#reset').addEventListener('click', () => {
    if (state.phase !== 'setup') return;
    dispatch({ type: 'RESET' });
    input.value = state.studentCount;
    validateInput();
  });
  $('#shuffle').addEventListener('click', async () => {
    if (state.phase !== 'setup') return;
    if (!validateInput()) { input.focus(); return; }
    dispatch({ type: 'SHUFFLE' });
    if (state.phase !== 'countdown') return;
    $('#countdown-overlay').focus();
    await runCountdown((value) => {
      if (state.countdown !== value) dispatch({ type: 'TICK', value });
    });
    dispatch({ type: 'COMPLETE' });
    $('#main-title').focus({ preventScroll: true });
  });
  $('#help').addEventListener('click', () => $('#help-dialog').showModal());
  $('#close-help').addEventListener('click', () => $('#help-dialog').close());
  renderState();
  $('#main-title').focus({ preventScroll: true });
}

app.innerHTML = welcomeScreen();
$('#start').addEventListener('click', start, { once: true });
