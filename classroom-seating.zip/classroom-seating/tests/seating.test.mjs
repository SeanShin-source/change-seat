import test from 'node:test';
import assert from 'node:assert/strict';
import { createSeats, createInitialState, reduceState } from '../src/state.js';
import { createSeatAssignments, verifyAssignments, shuffleArray } from '../src/seatAssignment.js';
import { isProtectedSeat, isDistantFromAnchor } from '../src/seatAssignmentRules.js';
import { parseStudentCount } from '../src/validation.js';
import { runCountdown } from '../src/countdown.js';

test('6 × 6 좌석이 서로 다른 좌표로 생성된다', () => {
  const seats = createSeats();
  assert.equal(seats.length, 36);
  assert.equal(new Set(seats.map((s) => s.id)).size, 36);
  assert.ok(seats.every((s) => s.active && s.student === null && s.row >= 0 && s.row < 6 && s.col >= 0 && s.col < 6));
});

test('학생 수 입력의 경계값과 비정상 입력을 검증한다', () => {
  for (const value of ['', '0', '31', '-1', '1.5', 'abc', '1e1', 'Infinity', ' 2 ']) assert.equal(parseStudentCount(value), null);
  for (let n = 1; n <= 30; n++) assert.equal(parseStudentCount(String(n)), n);
});

test('좌석 선택, 모두 활성화, 초기화와 보호 좌석 정책', () => {
  let state = reduceState(createInitialState(), { type: 'START' });
  state = reduceState(state, { type: 'TOGGLE_SEAT', id: '0-0' });
  assert.equal(state.seats[0].active, false);
  state = reduceState(state, { type: 'TOGGLE_SEAT', id: '0-0' });
  assert.equal(state.seats[0].active, true);
  for (const id of ['4-0', '4-1', '5-0']) state = reduceState(state, { type: 'TOGGLE_SEAT', id });
  assert.ok(state.seats.every((s) => s.active));
  state = reduceState(state, { type: 'TOGGLE_SEAT', id: '0-1' });
  state = reduceState(state, { type: 'ACTIVATE_ALL' });
  assert.ok(state.seats.every((s) => s.active));
  state = reduceState(state, { type: 'SET_COUNT', value: 12 });
  state = reduceState(state, { type: 'RESET' });
  assert.equal(state.studentCount, 26);
  assert.equal(state.phase, 'setup');
});

test('좌석이 부족하면 카운트다운을 시작하지 않는다', () => {
  let state = reduceState(createInitialState(), { type: 'START' });
  for (let i = 0; i < 11; i++) state = reduceState(state, { type: 'TOGGLE_SEAT', id: state.seats[i].id });
  state = reduceState(state, { type: 'SHUFFLE' });
  assert.equal(state.phase, 'setup');
  assert.equal(state.error, '학생 수보다 사용 가능한 좌석이 부족합니다.');
});

test('모든 학생 수와 다양한 비활성 좌석에서 중복, 누락 및 규칙 위반이 없다', () => {
  for (let count = 1; count <= 30; count++) {
    for (let run = 0; run < 100; run++) {
      const seats = createSeats();
      const candidates = shuffleArray(seats.filter((s) => !isProtectedSeat(s)));
      const disabled = run % (Math.min(36 - count, candidates.length) + 1);
      for (const seat of candidates.slice(0, disabled)) seat.active = false;
      const result = createSeatAssignments(count, seats);
      assert.equal(verifyAssignments(count, result), true);
      assert.deepEqual(result.filter((s) => s.student !== null).map((s) => s.student).sort((a, b) => a - b), Array.from({length: count}, (_, i) => i + 1));
      assert.ok(result.filter((s) => !s.active).every((s) => s.student === null));
      assert.equal(result.filter((s) => s.active && s.student === null).length, 36 - disabled - count);
      if (count >= 2) assert.equal(result[30].student, 2);
      if (count >= 18) assert.equal(result[24].student, 18);
      if (count >= 25) assert.equal(result[25].student, 25);
      for (const student of [20, 21, 26].filter((n) => n <= count)) {
        assert.equal(isDistantFromAnchor(result.find((s) => s.student === student)), true);
      }
      assert.ok(seats.every((s) => s.student === null));
    }
  }
});

test('배정 조건이 훼손되면 결과를 생성하지 않는다', () => {
  const seats = createSeats();
  seats[30].active = false;
  assert.throws(() => createSeatAssignments(26, seats));
  for (const count of [0, 31, 2.5, NaN]) assert.throws(() => createSeatAssignments(count, createSeats()));
});

test('일반 학생과 여분의 빈자리 위치가 충분히 변한다', () => {
  const layouts = new Set();
  const positions = new Set();
  const emptyPositions = new Set();
  for (let run = 0; run < 200; run++) {
    const seats = createSeatAssignments(26, createSeats());
    layouts.add(seats.map((s) => s.student).join(','));
    positions.add(seats.findIndex((s) => s.student === 1));
    seats.forEach((s, i) => { if (s.student === null) emptyPositions.add(i); });
  }
  assert.ok(layouts.size > 190);
  assert.ok(positions.size >= 20);
  assert.equal(emptyPositions.size, 33);
});

test('추가 거리 조건을 충족하면서 대상 학생들의 자리는 매번 무작위로 변한다', () => {
  const positions = new Map([[20, new Set()], [21, new Set()], [26, new Set()]]);
  for (let run = 0; run < 200; run++) {
    const result = createSeatAssignments(26, createSeats());
    assert.equal(result[25].student, 25);
    for (const [student, set] of positions) {
      const seat = result.find((s) => s.student === student);
      assert.ok(isDistantFromAnchor(seat));
      set.add(seat.id);
    }
  }
  for (const set of positions.values()) assert.ok(set.size >= 25);
});

test('카운트다운과 완료 중에는 모든 설정 변경 및 재배정을 막는다', () => {
  let state = reduceState(createInitialState(), { type: 'START' });
  state = reduceState(state, { type: 'SHUFFLE' });
  assert.equal(state.phase, 'countdown');
  const actions = [{ type: 'RESET' }, { type: 'START' }, { type: 'ACTIVATE_ALL' }, { type: 'TOGGLE_SEAT', id: '0-0' }, { type: 'SET_COUNT', value: 1 }, { type: 'SHUFFLE' }];
  for (const action of actions) assert.equal(reduceState(state, action), state);
  state = reduceState(state, { type: 'COMPLETE' });
  assert.equal(state.phase, 'complete');
  for (const action of [...actions, {type: 'COMPLETE'}, {type: 'TICK', value: 2}]) assert.equal(reduceState(state, action), state);
});

test('3, 2, 1이 각각 1초씩 진행된 뒤 완료된다', async () => {
  let time = 0;
  const ticks = [];
  await runCountdown((n) => ticks.push([n, time]), async (ms) => { time += ms; });
  assert.deepEqual(ticks, [[3, 0], [2, 1000], [1, 2000]]);
  assert.equal(time, 3000);
});
